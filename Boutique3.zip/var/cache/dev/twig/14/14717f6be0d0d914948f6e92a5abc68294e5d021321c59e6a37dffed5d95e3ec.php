<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @App/Admin/list_commande.html.twig */
class __TwigTemplate_6c1bbb73e94e8761d11bb9e7b13dc6e9e5a4e617cbfd635bb2d673c6944ff235 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@App/Admin/list_commande.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@App/Admin/list_commande.html.twig"));

        $this->parent = $this->loadTemplate("layout.html.twig", "@App/Admin/list_commande.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Boutique - gestion commandes";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "\t\t<h4>Nombre de commandes : ";
        echo twig_escape_filter($this->env, twig_length_filter($this->env, ($context["commandes"] ?? $this->getContext($context, "commandes"))), "html", null, true);
        echo "</h4>
\t    <table class=\"table table-dark\">
        <thead>
            <tr>
                <th>ID</th>
\t\t\t\t<th>Montant</th>
\t\t\t\t<th>Date</th>
\t\t\t\t<th>Membre</th>
\t\t\t\t<th>Etat</th>
                <th colspan=\"3\">Action</th>
            </tr>
        </thead>
\t<tbody>
\t\t";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["commandes"] ?? $this->getContext($context, "commandes")));
        foreach ($context['_seq'] as $context["_key"] => $context["c"]) {
            // line 20
            echo "\t\t\t<tr>
\t\t\t\t<td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["c"], "id", []), "html", null, true);
            echo "</td>
\t\t\t\t<td>";
            // line 22
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["c"], "montant", []), 2, ",", " "), "html", null, true);
            echo "€</td>
\t\t\t\t<td>";
            // line 23
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["c"], "dateEnregistrement", []), "d/m/Y H:i:s"), "html", null, true);
            echo "</td>
\t\t\t\t<td>
\t\t\t\t\t";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["c"], "membreId", []), "prenom", []), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["c"], "membreId", []), "nom", []), "html", null, true);
            echo " (id ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["c"], "membreId", []), "id", []), "html", null, true);
            echo ")<br/>
\t\t\t\t\t";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["c"], "membreId", []), "adresse", []), "html", null, true);
            echo "<br/>
\t\t\t\t\t";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["c"], "membreId", []), "codePostal", []), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["c"], "membreId", []), "ville", []), "html", null, true);
            echo "
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t";
            // line 30
            if (($this->getAttribute($context["c"], "etat", []) == 0)) {
                echo "<strong style=\"color:red\">En cours de traitement</strong>
\t\t\t\t";
            } elseif (($this->getAttribute(            // line 31
$context["c"], "etat", []) == 1)) {
                echo "<strong style=\"color:orange\">En cours de livraison</strong>
\t\t\t\t";
            } elseif (($this->getAttribute(            // line 32
$context["c"], "etat", []) == 2)) {
                echo "<strong style=\"color:lightgreen\">Livrée</strong>
\t\t\t\t";
            } else {
                // line 33
                echo "<strong>Autre</strong>
\t\t\t\t";
            }
            // line 35
            echo "\t\t\t\t</td>
\t\t\t</tr>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "\t</tbody>
</table>



 
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@App/Admin/list_commande.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 38,  153 => 35,  149 => 33,  144 => 32,  140 => 31,  136 => 30,  128 => 27,  124 => 26,  116 => 25,  111 => 23,  107 => 22,  103 => 21,  100 => 20,  96 => 19,  79 => 6,  70 => 5,  52 => 3,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'layout.html.twig' %}

{% block title %}Boutique - gestion commandes{% endblock %}

{% block content %}
\t\t<h4>Nombre de commandes : {{ commandes | length }}</h4>
\t    <table class=\"table table-dark\">
        <thead>
            <tr>
                <th>ID</th>
\t\t\t\t<th>Montant</th>
\t\t\t\t<th>Date</th>
\t\t\t\t<th>Membre</th>
\t\t\t\t<th>Etat</th>
                <th colspan=\"3\">Action</th>
            </tr>
        </thead>
\t<tbody>
\t\t{% for c in commandes %}
\t\t\t<tr>
\t\t\t\t<td>{{ c.id }}</td>
\t\t\t\t<td>{{ c.montant | number_format(2, ',', ' ') }}€</td>
\t\t\t\t<td>{{ c.dateEnregistrement | date(\"d/m/Y H:i:s\") }}</td>
\t\t\t\t<td>
\t\t\t\t\t{{ c.membreId.prenom }} {{ c.membreId.nom }} (id {{ c.membreId.id }})<br/>
\t\t\t\t\t{{ c.membreId.adresse }}<br/>
\t\t\t\t\t{{ c.membreId.codePostal }} {{ c.membreId.ville }}
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t{% if c.etat == 0 %}<strong style=\"color:red\">En cours de traitement</strong>
\t\t\t\t{% elseif c.etat == 1 %}<strong style=\"color:orange\">En cours de livraison</strong>
\t\t\t\t{% elseif c.etat == 2 %}<strong style=\"color:lightgreen\">Livrée</strong>
\t\t\t\t{% else %}<strong>Autre</strong>
\t\t\t\t{% endif %}
\t\t\t\t</td>
\t\t\t</tr>
\t\t{% endfor %}
\t</tbody>
</table>



 
{% endblock %}", "@App/Admin/list_commande.html.twig", "C:\\xampp\\htdocs\\Symfony\\Boutique3\\src\\AppBundle\\Resources\\views\\Admin\\list_commande.html.twig");
    }
}
