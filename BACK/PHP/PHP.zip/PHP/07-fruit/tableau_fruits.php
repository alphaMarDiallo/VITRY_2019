<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Tableau Fruits PHP</title>
</head>
<body>
    <!--
        1- Déclarer un tableau ARRAY avec tout les fruits
        2- Déclarer un tableau ARRAY avec les poids suivants : 100, 500, 1000, 1500, 2000, 3000, 5000, 10000.
        3- Affichez les 2 tableaux
        4- Sortir le fruit "cerises" et le poids 500 en passant par vos tableaux pour les transmettres à la fonction "calcul()" et obtenir le prix.
        5- Sortir tout les prix pour les cerises avec tout les poids (indice: boucle).
        6- Sortir tout les prix pour tout les fruits avec tout les poids (indice: boucle imbriquée).
        7- Faire un affichage dans une table HTML pour une présentation plus sympa.
    -->
</body>
</html>