<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Mon site de la mort qui tue!!!!</title>
</head>
<body>
    <div class="container">
        <header class="bg-secondary p-4 d-flex">
            <img src="maxresdefault.jpg" alt="mon image" style="width: 150px; height: 90px;" class="m-2">
            <h1 class="display-4">Mon site de la mort qui tue!!!</h1>
        </header>