        <footer class="text-center p-2 bg-secondary">
            &copy; 2019 GL - Pas touche c'est mon site à moi !!
        </footer>
    </div>
</body>
</html>