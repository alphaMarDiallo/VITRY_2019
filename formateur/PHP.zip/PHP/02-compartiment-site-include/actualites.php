<?php
require_once("include/header.php");
require_once("include/nav.php");    
?> 

    <section class="p-4 text-center border border-dark" style="height:400px">
        Voici le contenu de la page acualités<br>
        Voici le contenu de la page acualités<br>
        Voici le contenu de la page acualités<br>
        Voici le contenu de la page acualités<br>
        Voici le contenu de la page acualités<br>
    </section>

<?php
require_once("include/footer.php");
        
        