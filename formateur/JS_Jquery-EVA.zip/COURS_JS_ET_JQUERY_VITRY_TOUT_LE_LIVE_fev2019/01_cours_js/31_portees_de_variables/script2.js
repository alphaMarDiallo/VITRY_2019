var nom = 'jacquot';

function ditSalut() {
    alert('Salut' + nom);
}