var nom = 'valerie';

function ditSalut(){
    alert('Salut' + nom);
}