<?php 

$pdo = new PDO('mysql:host=localhost;dbname=entreprise_pole_s', 'root', '');