<?php

/*
 * SUJET
 *
 *  Vous travaillez pour la SPA. Dans le cadre de la refonte du site, vous devez créer une class Chat()​ ​qui aura les ​propriétés privées suivantes :
 * - Prénom (string de 3 à 20 caractères)
 * - Age (int)
 * - Couleur (string de 3 à 10 caractères)
 * - Sexe (string : male ou femelle)
 * - Race (string de 3 à 20 caractères)
 *
 * Faire les getters/setters permettant de valider le type de données ci-dessus ainsi que le constructeur permettant d’instancier la classe.
 * => Setter : Affecter une valeur
 * => Getter : Voir/afficher
 * 
 * Ajouter une méthode ​getInfos()​ permettant de retourner la totalité des propriétés sous forme de tableau.

 * Dans un nouveau fichier, instancier la classe afin de pouvoir afficher 3 chats différents et afficher le résultat à l’aide de la méthode ​getInfos()​ précédemment créée.
*/

/*
 * CORRECTION
 * -> index.php
 * -> class/Chat.php
 */
