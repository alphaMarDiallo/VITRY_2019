<!DOCTYPE html>
<html>
	<head>
<!--		<link rel="stylesheet" type="text/css" href="scroll.css" />-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="ajax.js"></script>
	</head>
	<body>
		<button id="submit" >Affichager les produits</button>
		<table id="resultat" border="1"></table>
	</body>
</html>
